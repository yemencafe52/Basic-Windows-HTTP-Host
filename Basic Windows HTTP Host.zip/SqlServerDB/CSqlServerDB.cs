﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace SqlServerDB
{
    public class CSqlServerDB
    {
        private readonly string connectionString;

        public CSqlServerDB(string connectionString)
        {
            this.connectionString = connectionString;
        }
        public int ExecuteNoneQuery(string sql)
        {
            int res = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(this.connectionString))
                {
                    con.Open();
                    SqlCommand sqlCommand = new SqlCommand(sql, con);
                    res = sqlCommand.ExecuteNonQuery();
                }
            }
            catch { }
            return res;
        }

        public int ExecuteQuery(string sql,ref DataTable dataTable)
        {
            int res = 0;
            try
            {
                using (SqlDataAdapter adp = new SqlDataAdapter(sql, new SqlConnection(this.connectionString)))
                {
                    adp.Fill(dataTable);
                    res = dataTable.Rows.Count;
                }
            }
            catch { }
            return res;
        }
    }
}
