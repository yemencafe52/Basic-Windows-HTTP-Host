﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookCore
{
    public interface IPeopleController
    {
        bool Create(CPerson cPerson);
        bool Update(CPerson cPerson);
        bool Delete(int number);
        CPerson Read(int number);
        List<CPerson> Search(string txt);
    
    }
}
