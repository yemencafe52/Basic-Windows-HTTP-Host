﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookCore
{
    public class MyJT
    {
        public string code { set; get; }
        public string message { set; get; }
    }
    public class CMyJsonConverter
    {
        public string GetJsonType(CPerson cPerson)
        {
            string res = "";
            res = Newtonsoft.Json.JsonConvert.SerializeObject(cPerson);
            return res;
        }

        public string GetJsonType(MyJT myJT)
        {
            string res = "";
            res = Newtonsoft.Json.JsonConvert.SerializeObject(myJT);
            return res;
        }

        public string GetJsonType(List<CPerson>p)
        {
            string res = "";
            res = Newtonsoft.Json.JsonConvert.SerializeObject(p);
            return res;
        }

        public CPerson GetPersonType(string j)
        {
            CPerson res = null;
            res = Newtonsoft.Json.JsonConvert.DeserializeObject<CPerson>(j);
            return res;
        }

        public MyJT GetMyJTType(string j)
        {
            MyJT res = null;
            res = Newtonsoft.Json.JsonConvert.DeserializeObject<MyJT>(j);
            return res;
        }

        public List<CPerson> GetPeople(string j)
        {
            List<CPerson> res =(List<CPerson>)Newtonsoft.Json.JsonConvert.DeserializeObject<IList<CPerson>>(j);
            return res;
        }
    }
}
