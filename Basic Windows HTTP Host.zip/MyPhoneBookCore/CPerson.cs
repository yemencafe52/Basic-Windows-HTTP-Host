﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookCore
{
    public class CPerson
    {
        //public int perNumber;
        //public string perName;
        //public string perPhoneNumber;

        public CPerson(
            int perNumber,
            string perName,
            string perPhoneNumber
            )
        {
            this.Number = perNumber;
            this.Name = perName;
            this.PhoneNumber = perPhoneNumber;
        }

        public int Number { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
    }
}
