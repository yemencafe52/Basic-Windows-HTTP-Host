﻿using HTTPCore;
using MyPhoneBookCore;

namespace MyPhoneBookHost
{
    internal class CHttpPutMethodProcesser
    {
        private CHttpRequest cHttpRequest;

        public CHttpPutMethodProcesser(CHttpRequest cHttpRequest)
        {
            this.cHttpRequest = cHttpRequest;
        }

        public CHttpRespone GetRespone()
        {
            CHttpRespone cHttpRespone = new CHttpRespone("500", "application/json", "-1", "close", "{\"error\": True, \"Message\": \"OOPS, SOMETHING WENT WRONG :(\"}");

            CPerson cPerson = new CMyJsonConverter().GetPersonType(cHttpRequest.Data);

            SqlServerDB.CSqlServerDB cSqlServerDB = new SqlServerDB.CSqlServerDB(Config.ConnectionString);
            if (new CPeopleController(cSqlServerDB).Update(cPerson))
            {
                cHttpRespone = new CHttpRespone("200", "application/json", "-1", "close", "{\"error\": False, \"Message\": \"\"}");
            }

            return cHttpRespone;
        }
    }
}