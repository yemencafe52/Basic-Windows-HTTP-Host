﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookHost
{
    internal class Config
    {
        private static string connectionString = @"Data Source=(localdb)\v11.0;Initial Catalog=MyPhoneNoteBookDB;Integrated Security=True;Pooling=False";
        internal static string ConnectionString => connectionString;
    }
}
