﻿using HTTPCore;
using IRequestProcesser;
using MyPhoneBookCore;
using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookHost
{
    internal class RequestProcess:IProcesser
    {
        void IProcesser.Process(Socket s)
        {
            ClientRequest cr= new ClientRequest(s);
            cr.Process();
        }
    }

    internal class ClientRequest
    {
        private Socket s;
        internal ClientRequest(Socket s)
        {
            this.s = s;
        }

        internal void Process()
        {
            byte[] buffer = new byte[1024 * 8];
            int len = this.s.Receive(buffer);

            if (len > 0)
            {
                byte[] temp = new byte[len];
                Array.Copy(buffer, 0, temp, 0, len);
                CHttpRequest cHttpRequest = new CHttpRequest(Encoding.UTF8.GetString(temp));
                CHttpRespone cHttpRespone = new CHttpRespone("500", "application/json", "-1", "close", "{\"error\": True, \"Message\": \"OOPS, SOMETHING WENT WRONG :(\"}");

                switch (cHttpRequest.Method)
                {
                    case "GET":
                        {   
                            cHttpRespone = new CHttpGetMethodProcesser(cHttpRequest).GetRespone();
                        }
                        break;

                    case "POST":
                        {
                            cHttpRespone = new CHttpPostMethodProcesser(cHttpRequest).GetRespone();
                        }
                        break;

                    case "PUT":
                        {
                            cHttpRespone = new CHttpPutMethodProcesser(cHttpRequest).GetRespone();
                        }
                        break;

                    case "DELETE":
                        {
                            cHttpRespone = new CHttpDeleteMethodProcesser(cHttpRequest).GetRespone();
                        }

                        break;
                }

                List<byte> ar0 = new List<byte>();
                ar0.AddRange(cHttpRespone.ToBytes());

                while (ar0.Count > 0)
                {
                    int len0 = s.Send(ar0.ToArray());
                    ar0.RemoveRange(0, len0);
                }
            }

            this.s.Close();
        }
    }
}