﻿using MyTCPServer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using HTTPCore;
using MyPhoneBookCore;
using MyPhoneBook;

namespace MyPhoneBookHost
{
    class CProgram
    {
        static void Main(string[] args)
        {
            MyTCPServer.MyTCPServer myTCPServer = new MyTCPServer.MyTCPServer(152, new RequestProcess());
            if (myTCPServer.Start())
            {
                //FrmMain frmMain = new FrmMain();
                //frmMain.ShowDialog();

                Console.WriteLine("Server is running...");
                Thread.Sleep(-1);
            }
            else
            {
                Console.WriteLine("OOPS, SOMETHING WENT WRONG :(\r\n Press any key to exit.");
                int x = Console.Read();
            }

        }
    }
}
