﻿using HTTPCore;
using MyPhoneBookCore;

namespace MyPhoneBookHost
{
    internal class CHttpDeleteMethodProcesser
    {
        private CHttpRequest cHttpRequest;

        public CHttpDeleteMethodProcesser(CHttpRequest cHttpRequest)
        {
            this.cHttpRequest = cHttpRequest;
        }

        public CHttpRespone GetRespone()
        {
            CHttpRespone cHttpRespone = new CHttpRespone("500", "application/json", "-1", "close", "{\"error\": True, \"Message\": \"OOPS, SOMETHING WENT WRONG :(\"}");

            MyJT myJT = new CMyJsonConverter().GetMyJTType(this.cHttpRequest.Data);
            int number = int.Parse(myJT.message);

            SqlServerDB.CSqlServerDB cSqlServerDB = new SqlServerDB.CSqlServerDB(Config.ConnectionString);
            bool res = new CPeopleController(cSqlServerDB).Delete(number);
            if ((res))
            {
                cHttpRespone = new CHttpRespone("200", "application/json", "-1", "close", "{\"error\": False, \"Message\": \"DONE\"}");
            }

            return cHttpRespone;
        }
    }
}