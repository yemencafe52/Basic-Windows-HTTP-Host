﻿using MyPhoneBookCore;
using SqlServerDB;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPhoneBookHost
{
    class CPeopleController : IPeopleController
    {
        private readonly CSqlServerDB _sqlServerDB;
        public CPeopleController(CSqlServerDB _sqlServerDB)
        {
            this._sqlServerDB = _sqlServerDB;
        }
        public bool Create(CPerson cPerson)
        {
            bool res = false;
            string sql = string.Format("insert into tblPeople (perName,perPhone) values(N'{0}',N'{1}')",new object[] { cPerson.Name,cPerson.PhoneNumber } );
            res = this._sqlServerDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }

        public bool Delete(int number)
        {
            bool res = false;
            string sql = string.Format("delete from tblPeople where perNumber={0}", new object[] { number });
            res = this._sqlServerDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }

        public CPerson Read(int number)
        {
            CPerson res = null;
            string sql = string.Format($"select perNumber,perName,perPhone from tblPeople where perNumber={number}");
            DataTable dt = new DataTable("tblTemp");
            if (this._sqlServerDB.ExecuteQuery(sql,ref dt) >0 )
            {
                res = new CPerson(
                    Convert.ToInt32(dt.Rows[0][0].ToString())
                    ,
                    dt.Rows[0][1].ToString()
                    ,
                    dt.Rows[0][2].ToString()
                    );
            }

            return res;
        }

        public List<CPerson> Search(string txt)
        {
            List<CPerson> res = new List<CPerson>();

            string sql = string.Format($"select perNumber,perName,perPhone from tblPeople where perName like('%{txt}%')");
            DataTable dt = new DataTable("tblTemp");

            if (this._sqlServerDB.ExecuteQuery(sql, ref dt) > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    res.Add(new CPerson(
                        Convert.ToInt32(dt.Rows[i][0].ToString())
                        ,
                        dt.Rows[i][1].ToString()
                        ,
                        dt.Rows[i][2].ToString()
                        ));
                }
            }

            return res;

        }

        public bool Update(CPerson cPerson)
        {
            bool res = false;
            string sql = string.Format("update tblPeople set perName=N'{0}',perPhone=N'{1}' where perNumber={2}", new object[] { cPerson.Name,cPerson.PhoneNumber,cPerson.Number });
            res = this._sqlServerDB.ExecuteNoneQuery(sql) > 0 ? true : false;
            return res;
        }
    }
}
