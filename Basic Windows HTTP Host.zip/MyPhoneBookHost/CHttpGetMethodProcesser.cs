﻿using HTTPCore;
using MyPhoneBookCore;
using System.Collections.Generic;

namespace MyPhoneBookHost
{
    internal class CHttpGetMethodProcesser
    {
        private CHttpRequest cHttpRequest;

        public CHttpGetMethodProcesser(CHttpRequest cHttpRequest)
        {
            this.cHttpRequest = cHttpRequest;
        }

        public CHttpRespone GetRespone()
        {
            CHttpRespone cHttpRespone = new CHttpRespone("500", "application/json", "-1", "close", "{\"error\": True, \"Message\": \"OOPS, SOMETHING WENT WRONG :(\"}");

            MyJT myJT = new CMyJsonConverter().GetMyJTType(this.cHttpRequest.Data);

            switch (myJT.code)
            {
                case "q":
                    {
                        int number = int.Parse(myJT.message);
                        SqlServerDB.CSqlServerDB cSqlServerDB = new SqlServerDB.CSqlServerDB(Config.ConnectionString);
                        CPerson res = new CPeopleController(cSqlServerDB).Read(number);
                        if (!(res is null))
                        {
                            cHttpRespone = new CHttpRespone("200", "application/json", "-1", "close", new CMyJsonConverter().GetJsonType(res));
                        }
                    }
                    break;

                case "s":
                    {
                        string txt = (myJT.message);
                        SqlServerDB.CSqlServerDB cSqlServerDB = new SqlServerDB.CSqlServerDB(Config.ConnectionString);
                        List<CPerson> res = new CPeopleController(cSqlServerDB).Search(txt);

                        if (!(res is null))
                        {
                            cHttpRespone = new CHttpRespone("200", "application/json", "-1", "close", new CMyJsonConverter().GetJsonType(res));
                        }
                    }
                    break;

            }
           
            return cHttpRespone;
        }
    }
}