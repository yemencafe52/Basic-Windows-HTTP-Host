﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace HTTPCore
{
    public class CHttpRequest
    {
        private string method;
        private string url;
        private string host;
        private string contentType;
        private string contentLength;
        private string connection;
        private string data;
     
        public CHttpRequest(
         string method,
         string url,
         string host,
         string contentType,
         string contentLength,
         string connection,
         string data
            )
        {
            this.method = method;
            this.url = url;
            this.host = host;
            this.contentType = contentType;
            this.contentLength = contentLength;
            this.connection = connection;
            this.data = data;
        }

        public CHttpRequest(string rawData)
        {
            CPropertyLineReader pr = new CPropertyLineReader(rawData);
            this.method = new CHttpMethodDetecter(pr.ReadLineByNumber(0)).GetMethod();
            this.url = new CHttpURLDetecter(pr.ReadLineByNumber(0)).GetURL();
            this.host = new CHttpHostDetecter(pr.ReadLineByPropertyName("host")).GetHost();
            this.contentType = new CHttpContentTypeDetecter(pr.ReadLineByPropertyName("content-type")).GetContentType();
            this.contentLength = new CHttpContentLengthDetecter(pr.ReadLineByPropertyName("content-length")).GetContentLength();
            this.connection = new CHttpConnectionDetecter(pr.ReadLineByPropertyName("connection")).GetConnectionType();
            this.data = new CHttpDataDetecter(rawData).GetRequestDATA();
        }

        public byte[] ToBytes()
        {
            return Encoding.UTF8.GetBytes(this.ToString());
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"{this.method} /{this.url} HTTP/1.1");
            sb.Append("\r\n");
            sb.Append($"Content-Type: {this.contentType}");
            sb.Append("\r\n");
            sb.Append($"ContentLength: {this.data.Length}");
            sb.Append("\r\n");
            sb.Append("Host: 127.0.0.1");
            sb.Append("\r\n");
            sb.Append($"connection: {this.connection}");
            sb.Append("\r\n");
            sb.Append("\r\n");
            sb.Append(this.data);
            return sb.ToString();
        }
        public bool Create(out CHttpRespone cHttpRespone)
        {
            bool res = false;
            cHttpRespone = null;

            try
            {
                
                Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                s.Connect("127.0.0.1", 152);

                s.Send(this.ToBytes());

                byte[] buffer = new byte[1024 * 8];
                List<byte> data = new List<byte>();

                int len = 0;
                while ((len = s.Receive(buffer)) > 0)
                {
                    byte[] temp = new byte[len];
                    Array.Copy(buffer, 0, temp, 0, len);
                    data.AddRange(temp);
                }

                cHttpRespone = new CHttpRespone(Encoding.UTF8.GetString(data.ToArray()));
                s.Close();

                res = true;
            }
            catch { }

            return res;
        }
        public string Method => method;
        public string URL => url;
        public string Host => host;
        public string ContentType => contentType;
        public string ContentLength => contentLength;
        public string Connection => connection;
        public string Data => data;
    }
}
