﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTPCore
{
    class CPropertyLineReader
    {
        private string[] rawDataLines;

        public CPropertyLineReader(string rawData)
        {
            this.rawDataLines = rawData.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
        }

        internal string ReadLineByNumber(int num)
        {
            string res = "";
            res = this.rawDataLines[num];
            return res;
        }

        internal string ReadLineByPropertyName(string name)
        {
            string res = "";

            foreach (string s in this.rawDataLines)
            {
                if (s.ToLower().StartsWith(name.ToLower()))
                {
                    res = s;
                    break;
                }
            }

            return res;
        }
    }
}
