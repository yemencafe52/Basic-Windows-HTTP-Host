﻿using System;

namespace HTTPCore
{
    internal class CHttpHostDetecter
    {
        private string v;

        public CHttpHostDetecter(string v)
        {
            this.v = v;
        }

        internal string GetHost()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.v.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}