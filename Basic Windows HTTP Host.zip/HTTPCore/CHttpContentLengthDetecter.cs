﻿using System;

namespace HTTPCore
{
    internal class CHttpContentLengthDetecter
    {
        private string v;

        public CHttpContentLengthDetecter(string v)
        {
            this.v = v;
        }

        internal string GetContentLength()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.v.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}