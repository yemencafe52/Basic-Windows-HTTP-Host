﻿using System;

namespace HTTPCore
{
    internal class CHttpConnectionDetecter
    {
        private string v;

        public CHttpConnectionDetecter(string v)
        {
            this.v = v;
        }

        internal string GetConnectionType()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.v.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}