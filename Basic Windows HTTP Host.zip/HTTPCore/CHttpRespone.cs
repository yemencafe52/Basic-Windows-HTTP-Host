﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTPCore
{
    public class CHttpRespone
    {
        private string status;
        private string contentType;
        private string contentLength;
        private string connection;
        private string data;

        public CHttpRespone(string rawData)
        {
            CPropertyLineReader pr = new CPropertyLineReader(rawData);
            this.status = new CHttpStatusCodeDetecter(pr.ReadLineByNumber(0)).GetStatus();  
            this.contentType = new CHttpContentTypeDetecter(pr.ReadLineByPropertyName("content-type")).GetContentType();
            this.contentLength = new CHttpContentLengthDetecter(pr.ReadLineByPropertyName("content-length")).GetContentLength();
            this.connection = new CHttpConnectionDetecter(pr.ReadLineByPropertyName("connection")).GetConnectionType();
            this.data = new CHttpDataDetecter(rawData).GetRequestDATA();
        }

        public CHttpRespone(
         string status,
         string contentType,
         string contentLength,
         string connection,
         string data
            )
        {
            this.status = status;
            this.contentType = contentType;
            this.contentLength = contentLength;
            this.connection = connection;
            this.data = data;
        }
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append($"HTTP/1.1 {this.status} {this.status}");
            sb.Append("\r\n");
            sb.Append($"Content-Type: {this.contentType}");
            sb.Append("\r\n");
            sb.Append($"Content-Length: {this.data.Length}");
            sb.Append("\r\n");
            sb.Append("Host: 127.0.0.1");
            sb.Append("\r\n");
            sb.Append($"connection: {this.connection}");
            sb.Append("\r\n");
            sb.Append("\r\n");
            sb.Append(this.data);
            return sb.ToString();
        }

        public byte[] ToBytes()
        {
            return Encoding.UTF8.GetBytes(this.ToString());
        }

        public string StatusCode => status;
        public string ContentType => contentType;
        public string ContentLength => contentLength;
        public string Connection => connection;
        public string Data => data;
    }
}
