﻿using System;

namespace HTTPCore
{
    internal class CHttpDataDetecter
    {
        private string v;

        public CHttpDataDetecter(string v)
        {
            this.v = v;
        }

        internal string GetRequestDATA()
        {
            string res = "";
            int pos = this.v.IndexOf("\r\n\r\n");
            if (pos > 0)
            {
                res = v.Substring(pos + 4, this.v.Length - pos - 4);
            }
            return res;
        }
    }
}