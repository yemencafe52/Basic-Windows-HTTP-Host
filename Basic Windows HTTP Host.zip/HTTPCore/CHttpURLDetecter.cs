﻿using System;

namespace HTTPCore
{
    internal class CHttpURLDetecter
    {
        private string v;

        public CHttpURLDetecter(string v)
        {
            this.v = v;
        }

        internal string GetURL()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.v.Split(new char[] { ' ' }, 3, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}