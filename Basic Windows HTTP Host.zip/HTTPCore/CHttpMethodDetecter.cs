﻿using System;

namespace HTTPCore
{
    internal class CHttpMethodDetecter
    {
        private readonly string rawHTTPLine;
        public CHttpMethodDetecter(string rawHTTPLine)
        {
            this.rawHTTPLine = rawHTTPLine;
        }

        internal string GetMethod()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.rawHTTPLine.Split(new char[] { ' ' },3, StringSplitOptions.RemoveEmptyEntries);
                res = ar[0];

            }
            catch { }

            return res;
        }
    }
}