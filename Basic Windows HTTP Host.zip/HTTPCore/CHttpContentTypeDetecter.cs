﻿using System;

namespace HTTPCore
{
    internal class CHttpContentTypeDetecter
    {
        private string v;

        public CHttpContentTypeDetecter(string v)
        {
            this.v = v;
        }

        internal string GetContentType()
        {
            string res = "#Error";
            try
            {
                string[] ar = this.v.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}