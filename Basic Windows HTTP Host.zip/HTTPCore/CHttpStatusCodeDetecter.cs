﻿using System;

namespace HTTPCore
{
    internal class CHttpStatusCodeDetecter
    {
        private string v;

        public CHttpStatusCodeDetecter(string v)
        {
            this.v = v;
        }

        internal string GetStatus()
        {
            string res = "500";
            try
            {
                string[] ar = this.v.Split(new char[] { ' ' }, 3, StringSplitOptions.RemoveEmptyEntries);
                res = ar[1];

            }
            catch { }

            return res;
        }
    }
}