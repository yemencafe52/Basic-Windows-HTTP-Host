﻿using IRequestProcesser;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace MyTCPServer
{
    public class MyTCPServer
    {
        private readonly int port;
        private IProcesser _iProcesser;
        private bool isRunning;
        private Socket s;

        public MyTCPServer(int port, IProcesser _iProcesser)
        {
            this.port = port;
            this._iProcesser = _iProcesser;

        }
        public bool Start()
        {
            bool res = false;

            if (!(isRunning))
            {
                this.s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                this.s.Bind(new IPEndPoint(IPAddress.Parse("0.0.0.0"), this.port));
                this.s.Listen(0);
                this.s.BeginAccept(new AsyncCallback(OnAccept), this.s);
                this.isRunning = true;
                res = true;
            }

            return res;
        }

        public bool Stop()
        {
            bool res = false;

            if ((isRunning))
            {
                this.s.Close();
                this.isRunning = false ;
                res = true;
            }

            return res;
        }

        private void OnAccept(IAsyncResult ar)
        {
            Socket r = this.s.EndAccept(ar);
            this.s.BeginAccept(new AsyncCallback(OnAccept), this.s);
            this._iProcesser.Process(r);
        }
    }
}
