﻿using MyPhoneBookCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPhoneBook
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            Preparing();
        }

        private bool Preparing()
        {
            bool res = false;
            return res;
        }

        private void Display(List<CPerson> cPeople)
        {
            this.dataGridView1.DataSource = cPeople;
            toolStripStatusLabel2.Text = cPeople.Count.ToString();
        }

        private void configToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmConfig frmConfig = new FrmConfig();
            frmConfig.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //FrmPersonMGR frmPersonMGR = new FrmPersonMGR();
            //frmPersonMGR.ShowDialog();
            //toolStripButton4.PerformClick();

            for (int i = 0; i < 10000; i++)
            {
                Task<bool>.Run(() =>
                {
                    new CPeopleController(CConfig.url).Create(new CPerson(0, $"person{i}", $"123{i}"));
                });
            }
        }


        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                int num = Convert.ToInt32(this.dataGridView1.Rows[this.dataGridView1.SelectedRows[0].Index].Cells[0].Value);

                CPerson person = new CPeopleController(CConfig.url).Read(num);
                FrmPersonMGR frmPersonMGR = new FrmPersonMGR(person);

                frmPersonMGR.ShowDialog();
                toolStripButton4.PerformClick();
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            List<CPerson> res = new CPeopleController(CConfig.url).Search(toolStripComboBox1.Text);
            Display(res);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (this.dataGridView1.SelectedRows.Count > 0)
            {
                int num = Convert.ToInt32(this.dataGridView1.Rows[this.dataGridView1.SelectedRows[0].Index].Cells[0].Value);

                new  CPeopleController(CConfig.url).Delete(num);

                toolStripButton4.PerformClick();
            }
        }
    }
}
