﻿using MyPhoneBookCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using HTTPCore;

namespace MyPhoneBook
{
    internal class CPeopleController : IPeopleController
    {
        private readonly string host;
        public CPeopleController(string host)
        {
            this.host = host;
        }
        public bool Create(CPerson cPerson)
        {
            bool res = false;

            HTTPCore.CHttpRequest cHttpRequest = new HTTPCore.CHttpRequest("POST","",this.host,"application/json","-1", "keep-alive", new CMyJsonConverter().GetJsonType(cPerson));
            CHttpRespone cHttpRespone;

            if (cHttpRequest.Create(out cHttpRespone))
            {
                if (cHttpRespone.StatusCode == "200")
                {
                    res = true;
                }
            }

            return res;
        }

        public bool Delete(int number)
        {
            bool res = false;

            MyJT myJT = new MyJT() { code = "0" ,message = $"{number}" };

            HTTPCore.CHttpRequest cHttpRequest = new HTTPCore.CHttpRequest("DELETE", "", this.host, "*", "-1", "keep-alive", new CMyJsonConverter().GetJsonType(myJT));
            CHttpRespone cHttpRespone;

            if (cHttpRequest.Create(out cHttpRespone))
            {
                if (cHttpRespone.StatusCode == "200")
                {
                    res = true;
                }
            }

            return res;
        }

        public CPerson Read(int number)
        {
            CPerson res = null ;

            MyJT myJT = new MyJT() { code = "q", message = $"{number}" };

            HTTPCore.CHttpRequest cHttpRequest = new HTTPCore.CHttpRequest("GET", "", this.host, "application/Json", "-1", "keep-alive", new CMyJsonConverter().GetJsonType(myJT));

            CHttpRespone cHttpRespone;

            if (cHttpRequest.Create(out cHttpRespone))
            {
                if (cHttpRespone.StatusCode == "200")
                {
                    res = new CMyJsonConverter().GetPersonType(cHttpRespone.Data);
                }
            }

            return res;
        }

        public List<CPerson> Search(string txt)
        {
            MyJT myJT = new MyJT() { code = "s", message = $"{txt}" };

            HTTPCore.CHttpRequest cHttpRequest = new HTTPCore.CHttpRequest("GET", "", this.host, "application/Json", "-1", "keep-alive", new CMyJsonConverter().GetJsonType(myJT));

            List<CPerson> res = new List<CPerson>();
            
            CHttpRespone cHttpRespone;

            if (cHttpRequest.Create(out cHttpRespone))
            {
                if (cHttpRespone.StatusCode == "200")
                {
                    res = new CMyJsonConverter().GetPeople(cHttpRespone.Data);
                }
            }

            return res;
        }

        public bool Update(CPerson cPerson)
        {
            bool res = false;

            HTTPCore.CHttpRequest cHttpRequest = new HTTPCore.CHttpRequest("PUT", "", this.host, "application/json", "-1", "keep-alive", new CMyJsonConverter().GetJsonType(cPerson));
            CHttpRespone cHttpRespone;

            if (cHttpRequest.Create(out cHttpRespone))
            {
                if (cHttpRespone.StatusCode == "200")
                {
                    res = true;
                }
            }

            return res;
        }
    }

    internal class CPeopleService
    {
        private readonly string url;
        public CPeopleService(string url)
        {
            this.url = url;
        }
        public async Task<bool> Create(CPerson cPerson)
        {
           return await Task.Run<bool>(()=>new CPeopleController(this.url).Create(cPerson));
        }

        public async Task<bool> Delete(int number)
        {
            return await Task.Run<bool>(() => new CPeopleController(this.url).Delete(number));
        }

        public async Task<CPerson> Read(int number)
        {
            return await Task.Run<CPerson>(() => new CPeopleController(this.url).Read(number));
        }

        public async Task<List<CPerson>> Search(string txt)
        {
            return await Task.Run<List<CPerson>>(() => new CPeopleController(this.url).Search(txt));
        }

        public async Task<bool> Update(CPerson cPerson)
        {
            return await Task.Run<bool>(() => new CPeopleController(this.url).Update(cPerson));
        }
    }
}
