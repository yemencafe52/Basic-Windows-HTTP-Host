﻿using MyPhoneBookCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyPhoneBook
{
    public partial class FrmPersonMGR : Form
    {
        CPerson person = null;
        public FrmPersonMGR()
        {
            InitializeComponent();
            numericUpDown1.Enabled = false;
        }

        public FrmPersonMGR(CPerson person)
        {
            InitializeComponent();
            numericUpDown1.Value = person.Number;
            textBox1.Text = person.Name;
            textBox2.Text = person.PhoneNumber;
            numericUpDown1.Enabled = false;
            this.person = person;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(person is null)
            {
                if(!(new CPeopleController(CConfig.url).Create(new CPerson(0, textBox1.Text, textBox2.Text))))
                {
                    MessageBox.Show("OOPS, SOMETHING WENT WRONG :(.");return;
                }
            }
            else
            {
                if (!(new CPeopleController(CConfig.url).Update(new CPerson((int)(numericUpDown1.Value), textBox1.Text, textBox2.Text))))
                {
                    MessageBox.Show("OOPS, SOMETHING WENT WRONG :(."); return;
                }
            }

            this.Close();
        }
    }
}
